"""
Arjun Srivastava
Section AB
HW1: Python Crash Course
Contains all hw1 methods
"""


def total(n):
    """
    Returns the sum of the numbers from 0 to n (inclusive).
    If n is negative, returns None.
    """
    if n < 0:
        return None
    else:
        result = 0
        for i in range(n + 1):
            result += i
        return result


def count_divisible_digits(n, m):
    """
    Takes two integer numbers n and m and
    returns the number of digits in n that are divisible by m
    Returns 0 if m == 0
    """
    count = 0
    n = abs(n)
    if m == 0:
        return 0
    while n > 0:
        if n % 10 == 0 or (n % 10) % m == 0:
            count += 1
        n //= 10
    return count


def is_relatively_prime(n, m):
    """
    Takes two integer numbers n and m and returns True if n and m are
    relatively prime (no common factors besides 1) to each other,
    returning False otherwise
    """
    for i in range(2, n + 1):
        if n % i == 0:
            if m % i == 0:
                return False
    return True


def travel(dir, x, y):
    """
    Takes a string of North, East, South, West directions,
    a starting location on a grid x, and a starting location on a grid y
    Returns a tuple that indicates the new position after
    following the directions starting from the given x, y
    Ignores any characters that are not N, E, S, or W (lowercase or uppercase)
    """
    x_new = x
    y_new = y
    dir = dir.upper()
    for direction in dir:
        if direction == 'N':
            y_new += 1
        elif direction == 'E':
            x_new += 1
        elif direction == 'S':
            y_new -= 1
        elif direction == 'W':
            x_new -= 1
    return x_new, y_new


def compress(s):
    """
    Takes a string as an argument and returns a new string such that
    each character is followed by its count, and
    any adjacent duplicate characters are
    removed (replaced by the single character)
    """
    count = 1
    compressed = ''
    if len(s) == 0:
        return compressed
    else:
        for i in range(len(s) - 1):
            if s[i] != s[i + 1]:
                compressed += s[i] + str(count)
                count = 1
            else:
                count += 1
        compressed += s[len(s) - 1] + str(count)
        return compressed


def longest_line_length(file_name):
    """
    Takes a string file_name and returns the length of
    the longest line in the file
    The length of the line is just the number of characters
    in it (whitespace or not)
    If the file is empty, the function should return None
    """
    longest = 0
    with open(file_name) as f:
        lines = f.readlines()
        for line in lines:
            if len(line) > longest:
                longest = len(line)
    if longest == 0:
        return None
    else:
        return longest


def longest_word(file_name):
    """
    Takes a string file_name and returns the longest
    word in the file with which line it appears on
    If there are ties for the longest word,
    returns the one that appears first in the file
    If the file is empty or there are no words in the file, returns None
    """
    longest = 0
    longestWord = None
    num = 0
    with open(file_name) as f:
        lines = f.readlines()
        lineNum = 0
        for line in lines:
            lineNum += 1
            line = line.strip()
            words = line.split()
            for word in words:
                if len(word) > longest:
                    longest = len(word)
                    longestWord = word
                    num = lineNum
    if longestWord is None:
        return None
    else:
        return str(num) + ': ' + longestWord


def get_average_in_range(numlist, low, high):
    """
    Accepts as parameter a list of integers, an integer low,
    and an integer high, and returns the average of all values within the list
    that lies in the given range from low (inclusive) to high (exclusive)
    If there are no values in the given range, returns 0
    """
    average = 0
    n = 0
    for num in numlist:
        if num in range(low, high):
            average += num
            n += 1
    if n == 0:
        return 0
    return average / n


def mode_digit(n):
    """
    Takes an integer number n and returns the digit
    that appears most frequently in that number.
    The given number can be + or -, but
    he most frequent digit returned will be non-negative
    If there is a tie for the most frequent digit,
    the digit with the greatest value is returned
    """
    n = abs(n)
    counts = {}
    mode = 0
    count = 0
    while n > 0:
        num = n % 10
        if num not in counts.keys():
            counts[num] = 1
        else:
            counts[num] += 1
        n //= 10
    for k, v in counts.items():
        if v > count:
            count = v
            mode = k
        elif v == count:
            if k > mode:
                mode = k
    return mode
