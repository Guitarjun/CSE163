import hw1

from cse163_utils import assert_equals
"""
Tests each method in hw1
"""


def test_total():
    """
    Tests the total method
    """
    # The regular case
    assert_equals(15, hw1.total(5))
    # Seems likely we could mess up 0 or 1
    assert_equals(1, hw1.total(1))
    assert_equals(0, hw1.total(0))

    # Test the None case
    assert_equals(None, hw1.total(-1))


def test_count_divisible_digits():
    """
    Tests count_divisible_digits
    """
    # Normal cases
    assert_equals(4, hw1.count_divisible_digits(650899, 3))
    assert_equals(0, hw1.count_divisible_digits(1234567, 8))
    # Testing negative
    assert_equals(1, hw1.count_divisible_digits(-204, 5))
    # Testing 0
    assert_equals(0, hw1.count_divisible_digits(-3245, 0))


def test_is_relatively_prime():
    """
    Tests is_relatively_prime
    """
    # False case
    assert_equals(False, hw1.is_relatively_prime(12, 14))
    assert_equals(False, hw1.is_relatively_prime(20, 30))
    assert_equals(False, hw1.is_relatively_prime(3, 3))
    # True case
    assert_equals(True, hw1.is_relatively_prime(1, 1))
    assert_equals(True, hw1.is_relatively_prime(14, 33))
    assert_equals(True, hw1.is_relatively_prime(12, 1))


def test_travel():
    """
    Tests travel
    """
    assert_equals((-1, 4), hw1.travel('NW!ewnW', 1, 2))
    assert_equals((2, 2), hw1.travel('DFfhio', 2, 2))
    assert_equals((3, -3), hw1.travel('nnSsW#3', 4, -3))
    assert_equals((7, 9), hw1.travel('SsSEWeE3462', 5, 12))


def test_compress():
    """
    Tests compress
    """
    assert_equals('c1o4l1k1a1n1g1a1r1o2', hw1.compress('coooolkangaroo'))
    assert_equals('', hw1.compress(''))
    assert_equals('f4', hw1.compress('ffff'))
    assert_equals('h1e1l2o2', hw1.compress('helloo'))


def test_longest_line_length():
    """
    Tests longest_line_length
    """
    assert_equals(35, hw1.longest_line_length('/home/song.txt'))
    assert_equals(67, hw1.longest_line_length('/home/test.txt'))
    assert_equals(25, hw1.longest_line_length('/home/test2.txt'))


def test_longest_word():
    """
    Tests longest_word
    """
    assert_equals('3: Merrily,', hw1.longest_word('/home/song.txt'))
    assert_equals(None, hw1.longest_word('/home/empty.txt'))
    assert_equals('1: definitely', hw1.longest_word('/home/test.txt'))
    assert_equals('1: should', hw1.longest_word('/home/test2.txt'))


def test_get_average_in_range():
    """
    Tests get_average_in_range
    """
    assert_equals(2.0, hw1.get_average_in_range([1, 2, 3], -1, 10))
    assert_equals(60.0, hw1.get_average_in_range([5, 1, 3, 114, 6], 6, 200))
    assert_equals(5.5, hw1.get_average_in_range([5, 6, 13, 14, 1], 4, 7))


def test_mode_digit():
    assert_equals(2, hw1.mode_digit(1211232231))
    assert_equals(0, hw1.mode_digit(-1240019000))
    assert_equals(4, hw1.mode_digit(44))
    assert_equals(9, hw1.mode_digit(-9))


def main():
    test_total()
    test_count_divisible_digits()
    test_is_relatively_prime()
    test_travel()
    test_compress()
    test_longest_line_length()
    test_longest_word()
    test_get_average_in_range()
    test_mode_digit()


if __name__ == '__main__':
    main()
